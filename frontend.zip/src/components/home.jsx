const Home = () => {
    return (
        <>
            <section class="graph-country">
                <div class="container">
                    <h3>Our Revenues</h3>
                    <div class="inner-graph">
                        <img src={require('../assets/images/graph.png')} alt="" />
                    </div>
                    <div class="graph-text-desc">
                        <h5>Canada</h5>
                        <p>Leverage agile frameworks to provide a robust synopsis for high level overviews. Iterative approaches to corporate strategy foster collaborative thinking to further the overall value proposition.Bring to the table win-win survival strategies to ensure proactive domination.
                            Leverage agile frameworks to provide a robust synopsis for high level overviews. Iterative approaches to corporate strategy foster collaborative thinking to further the overall value proposition.Bring to the table win-win survival strategies to ensure proactive domination.
                            Leverage agile frameworks to provide a robust synopsis for high level overviews. Iterative approaches to corporate strategy foster collaborative thinking to further the overall value proposition.Bring to the table win-win survival strategies to ensure proactive domination.
                            <a href="#"> Read more</a></p>
                    </div>
                </div>
            </section>
        </>
    )
}

export default Home;