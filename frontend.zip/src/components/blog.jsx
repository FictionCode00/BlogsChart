import { useState } from "react"
import { AllBlogs } from "../services/apiService"
import { useEffect } from "react"
import moment from "moment/moment"

const Blog = () => {
    const [blogs,setBlogs]=useState([])
    const BlogList=()=>{
        AllBlogs().then(response=>{
            if(response.status===200){
                setBlogs(response.data.data)
            }
        }).catch(err=>{
            console.log(err)
        })
    }

    useEffect(()=>{
        BlogList()
    },[])
    return (
        <>
            <section class="main-blog">
                <div class="container">
                    <div class="row d-flex align-items-center">
                        <div class="col-md-6">
                            <div class="main-log-left">
                                <h2>Growth & Culture</h2>
                                <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
                                <a href="#">Learn more </a>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="main-log-right">
                                <img src={require("../assets/images/blog-uper.png")} alt="" />
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <section class="reent-blog">
                <div class="container">
                    <h2>Most Recent Posts</h2>
                    <div class="row">
                        {blogs && blogs.map((blog)=>
                        <div class="col-md-4">
                            <div class="recent-blog-inner">
                                <span>{moment(blog.createdAt).format("DD")}<br/>
                                    {moment(blog.createdAt).format("MMM")}</span>
                                <img src={require("../assets/images/blog-one.png")} alt="" />
                                <div class="blog-data">
                                    <h5>{blog.title}</h5>
                                    {/* <p>We offer a comprehensive online QA Training course...  </p> */}
                                    <div dangerouslySetInnerHTML={{__html: blog.description}} />
                                </div>
                            </div>
                        </div>
                        )}
                        {/* <div class="col-md-4">
                            <div class="recent-blog-inner">
                                <span>15<br/>
                                    Aug</span>
                                <img src={require("../assets/images/blog-two.png")} alt="" />
                                <div class="blog-data">
                                    <h5>Language Course</h5>
                                    <p>We offer a comprehensive online QA Training course...  </p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="recent-blog-inner">
                                <span>15<br/>
                                    Aug</span>
                                <img src={require("../assets/images/blog-three.png")} alt="" />
                                <div class="blog-data">
                                    <h5>Language Course</h5>
                                    <p>We offer a comprehensive online QA Training course...  </p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="recent-blog-inner">
                                <span>15<br/>
                                    Aug</span>
                                <img src={require("../assets/images/blog-one.png")} alt="" />
                                <div class="blog-data">
                                    <h5>Language Course</h5>
                                    <p>We offer a comprehensive online QA Training course...  </p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="recent-blog-inner">
                                <span>15<br/>
                                    Aug</span>
                                <img src={require("../assets/images/blog-two.png")} alt="" />
                                <div class="blog-data">
                                    <h5>Language Course</h5>
                                    <p>We offer a comprehensive online QA Training course...  </p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="recent-blog-inner">
                                <span>15<br/>
                                    Aug</span>
                                <img src={require("../assets/images/blog-three.png")} alt="" />
                                <div class="blog-data">
                                    <h5>Language Course</h5>
                                    <p>We offer a comprehensive online QA Training course...  </p>
                                </div>
                            </div>
                        </div> */}
                    </div>
                </div>


            </section>
        </>
    )
}

export default Blog;